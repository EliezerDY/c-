//arraysI hw_3-Eliezer Brown
#include <iostream>
using namespace std;

int main() {

    // Declare an array of characters of capacity 5.
    char myArray[26];

    // Manually assign values to the array.
    myArray[0] = 'A';
    myArray[1] = 'B';
    myArray[2] = 'C';
    myArray[3] = 'D';
    myArray[4] = 'E';
    myArray[5] = 'F';
    myArray[6] = 'G';
    myArray[7] = 'H';
    myArray[8] = 'I';
    myArray[9] = 'J';
    myArray[10] = 'K';
    myArray[11] = 'L';
    myArray[12] = 'M';
    myArray[13] = 'N';
    myArray[14] = 'O';
    myArray[15] = 'P';
    myArray[16] = 'Q';
    myArray[17] = 'R';
    myArray[18] = 'S';
    myArray[19] = 'T';
    myArray[20] = 'U';
    myArray[21] = 'V';
    myArray[22] = 'W';
    myArray[23] = 'Z';
    myArray[24] = 'Y';
    myArray[25] = 'Z';

cout<<"Original: "<<myArray[0]<<" "<<myArray[1]<<" "<<myArray[2]<<" "<<myArray[3]<<" "<<myArray[4]<<" "<<myArray[5]<<" "<<myArray[6]<<" "<<myArray[7]<<" "<<myArray[8]
<<" "<<myArray[9]<<" "<<myArray[10]<<" "<<myArray[11]<<" "<<myArray[12]<<" "<<myArray[13]<<" "<<myArray[14]<<" "<<myArray[15]<<" "<<myArray[16]<<" "<<myArray[17]<<" "<<myArray[18]
<<" "<<myArray[19]<<" "<<myArray[20]<<" "<<myArray[21]<<" "<<myArray[22]<<" "<<myArray[23]<<" "<<myArray[24]<<" "<<myArray[25]<<endl;
cout<<"Reverse: ";
for(int i =25; i>=0; i--){
cout<<myArray[i]<<" ";
}
    // The boundaries of this loop exceeds the boundaries of the array
    // therefore accessing unintended memory cells.
  /*  for(int i=0; i<10; i++) {
        cout << "myArray[" << i << "] = " << myArray[i] << endl;
    }

    cout << endl << endl;*/
    return 0;
}
