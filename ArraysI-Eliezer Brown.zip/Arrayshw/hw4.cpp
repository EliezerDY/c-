//arraysI hw_4-Eliezer Brown
#include <iostream>
#include <iostream>
using namespace std;

int main() {

int num[4] = {1,2,3,4};

for(int i=0; i<4; i++) {
      cout << num[i] << " ";
      }
    cout << endl;
    int max=num[0];
    int min=num[0];
    for(int i=0;i<4;i++){
        // finding minimum number in array
          if(min>num[i]){
             min=num[i];
          }
          //finding maximum number in array
          if(max<num[i]){
          max=num[i];
          }
    }
           // displaying output
            cout<<"Maximum Number is:"<<max<<endl;
            cout<<"Minimum Number is:"<<min<<endl;





    return 0;
}
