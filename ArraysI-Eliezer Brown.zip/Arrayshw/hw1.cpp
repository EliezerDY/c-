//arraysI hw_1-Eliezer Brown
#include <iostream>
using namespace std;


  const  int grade =5;
int main() {

int grades[grade];
for (int i=0; i<grade;i++){
   cout<<"Enter a grade: ";
   cin>>grades[i];
}

cout<<"Grades: "<<grades[0]<<" "<<grades[1]<<" "<<grades[2]<<" "<<grades[3]<<" "<<grades[4];

cout<<endl;


double sum =0.0, average;
   for (int i=0; i<=grade; i++){
     sum +=grades[i];
  average =sum/grades[i];
   }
   //cout<<sum/5<<endl;
   cout<<"The average grade is "<<average<<".";

   return 0;
 }
